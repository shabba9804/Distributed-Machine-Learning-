ray start --head \
  --port=6379 \
  --node-ip-address=172.31.9.37 \
  --dashboard-host=0.0.0.0

  On worker:
ray start --address='172.31.9.37:6379'

Then (on head):
python distributed_ray.py