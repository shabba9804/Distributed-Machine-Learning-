import ray
import numpy as np
import pandas as pd
import time
import json
import os

#  CONFIG
LEARNING_RATE   = 0.01
EPOCHS          = 200
FEATURES        = 8
NORM_PATH       = "data/norm_stats.json"
FULL_DATA_PATH  = "data/full_dataset.csv"
PARTITION_PATHS = [
    "data/partition_0.csv",   # Worker 0
    "data/partition_1.csv",   # Worker 1
]
RESULTS_DIR = "results"
os.makedirs(RESULTS_DIR, exist_ok=True)


#  METRICS 
def mse(y, yp):  return float(np.mean((y - yp) ** 2))
def rmse(y, yp): return float(np.sqrt(mse(y, yp)))
def mae(y, yp):  return float(np.mean(np.abs(y - yp)))
def r2(y, yp):
    return float(1 - np.sum((y - yp) ** 2) / np.sum((y - np.mean(y)) ** 2))


#  RAY WORKER ACTOR 
@ray.remote
class GradientWorker:

    def __init__(self, partition_path: str, norm_path: str):
        with open(norm_path) as f:
            stats = json.load(f)
        mean = np.array(stats["mean"])
        std  = np.array(stats["std"])

        df        = pd.read_csv(partition_path)
        cols      = [c for c in df.columns if c != "target"]
        self.X    = (df[cols].values - mean) / std
        self.y    = df["target"].values
        self.n    = len(self.X)

    def compute_gradient(self, w: np.ndarray, b: float):
        yp  = self.X @ w + b
        err = yp - self.y
        gw  = np.clip((2 / self.n) * (self.X.T @ err), -1, 1)
        gb  = float(np.clip((2 / self.n) * np.sum(err), -1, 1))
        return gw, gb, self.n

    def get_n_samples(self) -> int:
        return self.n


#  TRAINING LOOP
def train(workers, X_full, y_full):
    w = np.zeros(FEATURES)
    b = 0.0
    loss_history = []

    n_per_worker = ray.get([wk.get_n_samples.remote() for wk in workers])
    n_total      = sum(n_per_worker)
    weights      = [n / n_total for n in n_per_worker]

    start = time.perf_counter()

    for epoch in range(EPOCHS):
        # Send current model to all workers — they compute IN PARALLEL
        futures = [wk.compute_gradient.remote(w.copy(), b) for wk in workers]
        results = ray.get(futures)

        # Weighted gradient average
        agg_gw = sum(wi * gw for wi, (gw, gb, _) in zip(weights, results))
        agg_gb = sum(wi * gb for wi, (gw, gb, _) in zip(weights, results))

        w -= LEARNING_RATE * agg_gw
        b -= LEARNING_RATE * agg_gb

        loss = mse(y_full, X_full @ w + b)
        loss_history.append({"epoch": epoch, "loss": round(loss, 6)})

        if epoch % 20 == 0 or epoch == EPOCHS - 1:
            print(f"  Epoch {epoch:>4d}/{EPOCHS}  MSE={loss:.4f}  R²={r2(y_full, X_full@w+b):.4f}")

    elapsed = time.perf_counter() - start
    return w, b, elapsed, loss_history


#  MAIN 
def main():
    print("=" * 60)
    print("  DISTRIBUTED TRAINING  (Ray)")
    print("=" * 60)


    ray.init(address="auto")

    cpus = int(ray.cluster_resources().get("CPU", 1))
    print(f"\n  Ray cluster  : {cpus} CPU(s) available")
    print(f"  Workers      : {len(PARTITION_PATHS)}\n")
    print(ray.cluster_resources())

    with open(NORM_PATH) as f:
        stats = json.load(f)
    mean = np.array(stats["mean"])
    std  = np.array(stats["std"])

    df_full   = pd.read_csv(FULL_DATA_PATH)
    cols_full = [c for c in df_full.columns if c != "target"]
    X_full    = (df_full[cols_full].values - mean) / std
    y_full    = df_full["target"].values
    print(f"[1] Full dataset : {len(X_full):,} samples, {X_full.shape[1]} features")

    print(f"[2] Spawning {len(PARTITION_PATHS)} worker actors …")
    workers      = [GradientWorker.remote(p, NORM_PATH) for p in PARTITION_PATHS]
    n_per_worker = ray.get([wk.get_n_samples.remote() for wk in workers])
    for i, (p, n) in enumerate(zip(PARTITION_PATHS, n_per_worker)):
        print(f"    Worker {i} : {n:,} samples  ({p})")

    print(f"\n[3] Training …\n")
    w, b, elapsed, loss_history = train(workers, X_full, y_full)

    y_pred = X_full @ w + b
    metrics = {
        "mode"               : "distributed_ray",
        "framework"          : "Ray",
        "num_workers"        : len(PARTITION_PATHS),
        "total_samples"      : int(len(X_full)),
        "samples_per_worker" : n_per_worker,
        "features"           : FEATURES,
        "epochs"             : EPOCHS,
        "learning_rate"      : LEARNING_RATE,
        "training_time_sec"  : round(elapsed, 4),
        "final_mse"          : round(mse(y_full, y_pred), 4),
        "final_rmse"         : round(rmse(y_full, y_pred), 4),
        "final_mae"          : round(mae(y_full, y_pred), 4),
        "r2_score"           : round(r2(y_full, y_pred), 4),
        "weights"            : w.tolist(),
        "bias"               : round(float(b), 4),
        "loss_history"       : loss_history,
    }

    out_path = os.path.join(RESULTS_DIR, "distributed_results.json")
    with open(out_path, "w") as f:
        json.dump(metrics, f, indent=2)

    print("\n" + "=" * 60)
    print("  RESULTS")
    print("=" * 60)
    print(f"  Training time : {elapsed:.4f} s")
    print(f"  MSE           : {metrics['final_mse']}")
    print(f"  RMSE          : {metrics['final_rmse']}")
    print(f"  MAE           : {metrics['final_mae']}")
    print(f"  R²            : {metrics['r2_score']}")
    print(f"\n  Results saved → {out_path}")

    ray.shutdown()


if __name__ == "__main__":
    main()